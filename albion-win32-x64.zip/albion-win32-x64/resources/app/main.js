const electron = require("electron")
const url = require("url")
const path = require("path")
let json = require(path.join(__dirname, '/dump.json'))
const { ipcMain } = require('electron')


const { app, BrowserWindow } = electron;

let mainWindow;

app.on('ready', () => {

    mainWindow = new BrowserWindow({

        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            enableRemoteModule: true
        }
    });
    mainWindow.loadFile("main.html")
})


ipcMain.handle('arama', async(event, someArgument) => {

    var result = 0
    for (i = 0; i < json.length; i++) {
        if (someArgument == json[i]["@displayname"]) {
            result = json[i]
        }
    }
    return result
})

ipcMain.handle('mapload', async(event) => {
    const maps = []
    for (i = 0; i < json.length; i++) {
        maps.push(json[i]["@displayname"])
    }
    return maps
})